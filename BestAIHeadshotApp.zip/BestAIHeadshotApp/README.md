# تطبيق Best AI Headshot - أندرويد

تطبيق أندرويد بسيط يعرض موقع Best AI Headshot باستخدام WebView.

## المميزات

- ✅ عرض صفحة الويب بشكل كامل
- ✅ دعم JavaScript
- ✅ السحب للأسفل لإعادة التحميل (Pull to Refresh)
- ✅ شريط تقدم التحميل
- ✅ زر الرجوع للتنقل بين الصفحات
- ✅ معالجة الأخطاء وعرض رسائل مناسبة
- ✅ دعم اللغة العربية في واجهة المستخدم
- ✅ قفل الشاشة في الوضع العمودي

## متطلبات التشغيل

- Android Studio Arctic Fox أو أحدث
- Android SDK 24 أو أحدث (Android 7.0+)
- Gradle 8.1.0 أو أحدث
- Kotlin 1.9.0 أو أحدث

## خطوات البناء والتشغيل

### 1. فتح المشروع في Android Studio

1. افتح Android Studio
2. اختر File → Open
3. انتقل إلى مجلد المشروع `BestAIHeadshotApp`
4. انقر على OK

### 2. انتظار مزامنة Gradle

- سيقوم Android Studio تلقائياً بمزامنة المشروع
- انتظر حتى تنتهي عملية التحميل (قد تستغرق بضع دقائق)

### 3. تشغيل التطبيق

#### على هاتف حقيقي:
1. فعّل "وضع المطور" و "تصحيح USB" في هاتفك الأندرويد
2. وصّل الهاتف بالكمبيوتر عبر USB
3. اختر جهازك من قائمة الأجهزة في Android Studio
4. انقر على زر Run (أو اضغط Shift+F10)

#### على محاكي (Emulator):
1. اذهب إلى Tools → Device Manager
2. انقر على Create Device
3. اختر جهاز (مثل Pixel 5)
4. اختر إصدار Android (يُنصح بـ API 30 أو أحدث)
5. انقر على Finish
6. شغّل المحاكي واختره من قائمة الأجهزة
7. انقر على Run

### 4. إنشاء ملف APK

#### لإنشاء APK للاختبار:
1. Build → Build Bundle(s) / APK(s) → Build APK(s)
2. انتظر حتى ينتهي البناء
3. ستظهر رسالة مع رابط لموقع الملف
4. الملف سيكون في: `app/build/outputs/apk/debug/app-debug.apk`

#### لإنشاء APK للإصدار (Release):
1. Build → Generate Signed Bundle / APK
2. اختر APK
3. أنشئ مفتاح توقيع جديد أو استخدم مفتاح موجود
4. اختر "release" كنوع البناء
5. انقر على Finish

## هيكل المشروع

```
BestAIHeadshotApp/
├── app/
│   ├── src/
│   │   └── main/
│   │       ├── java/com/bestaiheadshot/app/
│   │       │   └── MainActivity.kt          # النشاط الرئيسي
│   │       ├── res/
│   │       │   ├── layout/
│   │       │   │   └── activity_main.xml    # تخطيط الشاشة الرئيسية
│   │       │   ├── values/
│   │       │   │   ├── colors.xml           # الألوان
│   │       │   │   ├── strings.xml          # النصوص
│   │       │   │   └── themes.xml           # السمات
│   │       │   └── xml/
│   │       │       ├── backup_rules.xml
│   │       │       └── data_extraction_rules.xml
│   │       └── AndroidManifest.xml          # ملف البيان
│   ├── build.gradle                         # إعدادات بناء التطبيق
│   └── proguard-rules.pro                   # قواعد ProGuard
├── build.gradle                             # إعدادات بناء المشروع
├── settings.gradle                          # إعدادات المشروع
└── gradle.properties                        # خصائص Gradle
```

## المكونات الرئيسية

### MainActivity.kt
الملف الرئيسي الذي يحتوي على:
- إعدادات WebView (تفعيل JavaScript، التخزين المحلي، إلخ)
- معالج تحميل الصفحات
- معالج الأخطاء
- دعم زر الرجوع للتنقل

### activity_main.xml
تخطيط بسيط يحتوي على:
- SwipeRefreshLayout للسحب للتحديث
- WebView لعرض المحتوى
- ProgressBar لإظهار التقدم

## التخصيص

### تغيير رابط الموقع
افتح ملف `MainActivity.kt` وعدّل السطر:
```kotlin
private val websiteUrl = "https://bestaiheadshot.github.io/APP/"
```

### تغيير ألوان التطبيق
افتح ملف `res/values/colors.xml` وعدّل الألوان حسب رغبتك:
```xml
<color name="primary">#6200EE</color>
<color name="primary_dark">#3700B3</color>
<color name="accent">#03DAC5</color>
```

### تغيير اسم التطبيق
افتح ملف `res/values/strings.xml` وعدّل:
```xml
<string name="app_name">Best AI Headshot</string>
```

### تغيير أيقونة التطبيق
1. استخدم [Android Asset Studio](https://romannurik.github.io/AndroidAssetStudio/icons-launcher.html)
2. أو استخدم Android Studio: Right-click على `res` → New → Image Asset
3. اختر صورتك وقم بإنشاء الأيقونات

## الأذونات المطلوبة

التطبيق يطلب الأذونات التالية:
- `INTERNET` - للوصول إلى الإنترنت
- `ACCESS_NETWORK_STATE` - للتحقق من حالة الاتصال

## حل المشاكل الشائعة

### المشكلة: لا يتم تحميل الصفحة
**الحل:**
- تأكد من الاتصال بالإنترنت
- تحقق من صحة رابط الموقع
- تأكد من أن أذونات الإنترنت مفعّلة

### المشكلة: JavaScript لا يعمل
**الحل:**
- تأكد من وجود السطر `webSettings.javaScriptEnabled = true` في الكود

### المشكلة: خطأ في بناء المشروع
**الحل:**
- انقر على File → Invalidate Caches / Restart
- تأكد من تحديث Android Studio إلى آخر إصدار
- نظّف المشروع: Build → Clean Project
- أعد البناء: Build → Rebuild Project

### المشكلة: الصفحة لا تُعرض بشكل صحيح
**الحل:**
- تأكد من إعدادات viewport في WebView
- جرب إضافة meta tag في صفحة HTML

## الترخيص

هذا المشروع مفتوح المصدر ومتاح للاستخدام الحر.

## معلومات إضافية

- الموقع المعروض: https://bestaiheadshot.github.io/APP/
- الحد الأدنى لإصدار Android: 7.0 (API 24)
- الإصدار المستهدف: Android 14 (API 34)

## الدعم

إذا واجهت أي مشاكل أو لديك أسئلة:
1. راجع قسم "حل المشاكل الشائعة" أعلاه
2. تأكد من توافق إصدارات الأدوات المستخدمة
3. راجع سجلات الأخطاء في Logcat بـ Android Studio

---

تم إنشاء هذا المشروع باستخدام Android Studio و Kotlin 💚
